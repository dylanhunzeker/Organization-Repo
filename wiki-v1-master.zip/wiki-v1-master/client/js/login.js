'use strict'

/* global $ */

$(() => {
  $('#login-user').focus()
})
