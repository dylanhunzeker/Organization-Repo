### Actual behavior

### Expected behavior

### Steps to reproduce the behavior

<!--- FOR FEATURE REQUESTS: Use the feature request board instead: https://requests.requarks.io/wiki --->

<!-- Love Wiki.js? Please consider supporting our collective:
👉  https://opencollective.com/wikijs/donate -->
